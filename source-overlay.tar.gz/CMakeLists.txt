cmake_minimum_required(VERSION 3.22)
project(SkellSnap VERSION 0.1.0 LANGUAGES C CXX)

option(SNAP_BUILD_PLUGIN "Build the JUCE VST3/Standalone plugin (needs JUCE)" ON)
option(SNAP_BUILD_TESTS  "Build the portable DSP tests (no JUCE needed)" ON)

if(SNAP_BUILD_TESTS)
  enable_testing()
  add_executable(SnapCoreTests tests/test_snap.cpp)
  target_compile_features(SnapCoreTests PRIVATE cxx_std_17)
  target_compile_options(SnapCoreTests PRIVATE $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-O2>)
  add_test(NAME SnapCoreTests COMMAND SnapCoreTests --quick)
  # JUCE-free UI regression tests carried over from Necromancer (rune orbit, glyph catalogue, frame pacer)
  add_executable(SnapBench tests/bench_vowel.cpp)
  target_compile_features(SnapBench PRIVATE cxx_std_17)
  foreach(t rune_motion_test rune_glyph_catalog_test ui_frame_pacer_test)
    add_executable(Snap_${t} tests/${t}.cpp)
    target_compile_features(Snap_${t} PRIVATE cxx_std_17)
    add_test(NAME Snap_${t} COMMAND Snap_${t})
  endforeach()
endif()

if(SNAP_BUILD_PLUGIN)
  include(FetchContent)
  if(DEFINED JUCE_PATH AND EXISTS "${JUCE_PATH}/CMakeLists.txt")
    add_subdirectory("${JUCE_PATH}" JUCE)
  else()
    FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
                         GIT_TAG 8.0.12 GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(JUCE)
  endif()
  juce_add_plugin(SkellSnap
    COMPANY_NAME "Skell Audio"
    BUNDLE_ID "audio.skell.snap"
    PLUGIN_MANUFACTURER_CODE SkAu
    PLUGIN_CODE SkSn
    FORMATS VST3 Standalone
    PRODUCT_NAME "Skell-Snap"
    VST3_CATEGORIES Fx "Pitch Shift"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE)
  juce_generate_juce_header(SkellSnap)
  # Original SKELL artwork (shared with Skell-Necromancer) + Montserrat SemiBold (SIL OFL 1.1).
  # Override the display font with -DSKELL_DISPLAY_FONT=/path/to/font.ttf
  set(SNAP_ASSETS Assets/bg_brushed.png Assets/dial_well.png Assets/knob_cap_big.png
      Assets/knob_cap_small.png Assets/rune_atlas.png)
  if(NOT DEFINED SKELL_DISPLAY_FONT)
    set(SKELL_DISPLAY_FONT "${CMAKE_CURRENT_SOURCE_DIR}/Assets/fonts/Montserrat-SemiBold.ttf")
  endif()
  set(SNAP_FONT_FLAGS SKELL_HAS_DISPLAY_FONT=0 SKELL_HAS_MONO_FONT=0)
  file(MAKE_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/snap-fonts")
  if(EXISTS "${SKELL_DISPLAY_FONT}")
    configure_file("${SKELL_DISPLAY_FONT}" "${CMAKE_CURRENT_BINARY_DIR}/snap-fonts/display.ttf" COPYONLY)
    list(APPEND SNAP_ASSETS "${CMAKE_CURRENT_BINARY_DIR}/snap-fonts/display.ttf")
    set(SNAP_FONT_FLAGS SKELL_HAS_DISPLAY_FONT=1 SKELL_HAS_MONO_FONT=0)
  endif()
  juce_add_binary_data(SnapAssets SOURCES ${SNAP_ASSETS})
  target_sources(SkellSnap PRIVATE
    Source/PluginProcessor.cpp Source/PluginProcessor.h
    Source/PluginEditor.cpp Source/PluginEditor.h Source/Theme.h Source/dsp/SnapCore.h
    Source/ui/SnapDial.h Source/ui/RetuneScale.h Source/ui/SnapKnob.h Source/ui/SnapMeter.h Source/ui/NoteTablets.h
    Source/ui/SnapLookAndFeel.h Source/ui/RuneRing.h Source/ui/RuneMotion.h
    Source/ui/RuneGlyphCatalog.h Source/ui/RuneGlyphArtwork.h Source/ui/UiFramePacer.h)
  target_compile_features(SkellSnap PRIVATE cxx_std_17)
  target_compile_definitions(SkellSnap PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0 JUCE_DISPLAY_SPLASH_SCREEN=0 ${SNAP_FONT_FLAGS})
  target_link_libraries(SkellSnap PRIVATE SnapAssets
    juce::juce_audio_utils juce::juce_audio_processors juce::juce_gui_extra
    juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)
endif()
