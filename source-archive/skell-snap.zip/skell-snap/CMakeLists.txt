cmake_minimum_required(VERSION 3.22)
project(SkellSnap VERSION 0.1.0 LANGUAGES C CXX)

option(SNAP_BUILD_PLUGIN "Build the JUCE VST3/Standalone plugin (needs JUCE)" ON)
option(SNAP_BUILD_TESTS  "Build the portable DSP tests (no JUCE needed)" ON)

if(SNAP_BUILD_TESTS)
  enable_testing()
  add_executable(SnapCoreTests tests/test_snap.cpp)
  target_compile_features(SnapCoreTests PRIVATE cxx_std_17)
  target_compile_options(SnapCoreTests PRIVATE $<$<NOT:$<CXX_COMPILER_ID:MSVC>>:-O2>)
  add_test(NAME SnapCoreTests COMMAND SnapCoreTests --quick)
endif()

if(SNAP_BUILD_PLUGIN)
  include(FetchContent)
  if(DEFINED JUCE_PATH AND EXISTS "${JUCE_PATH}/CMakeLists.txt")
    add_subdirectory("${JUCE_PATH}" JUCE)
  else()
    FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
                         GIT_TAG 8.0.12 GIT_SHALLOW TRUE)
    FetchContent_MakeAvailable(JUCE)
  endif()
  juce_add_plugin(SkellSnap
    COMPANY_NAME "Skell Audio"
    BUNDLE_ID "audio.skell.snap"
    PLUGIN_MANUFACTURER_CODE SkAu
    PLUGIN_CODE SkSn
    FORMATS VST3 Standalone
    PRODUCT_NAME "Skell-Snap"
    VST3_CATEGORIES Fx "Pitch Shift"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE)
  juce_generate_juce_header(SkellSnap)
  target_sources(SkellSnap PRIVATE
    Source/PluginProcessor.cpp Source/PluginProcessor.h
    Source/PluginEditor.cpp Source/PluginEditor.h Source/dsp/SnapCore.h)
  target_compile_features(SkellSnap PRIVATE cxx_std_17)
  target_compile_definitions(SkellSnap PRIVATE JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0 JUCE_DISPLAY_SPLASH_SCREEN=0)
  target_link_libraries(SkellSnap PRIVATE
    juce::juce_audio_utils juce::juce_audio_processors juce::juce_gui_extra
    juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)
endif()
