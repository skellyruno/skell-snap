// Skell-Snap DSP core tests. No JUCE, no audio hardware.
// Each check measures the real output (pitch via fine DFT scan, latency via
// impulse, glitches via max sample step) instead of trusting internal state.
#include "../Source/dsp/SnapCore.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <random>

using namespace snap;
static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++g_fail; std::printf("  FAIL: "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

static std::vector<float> voice(double sr, double secs, double f0, double amp = 0.3,
                                double noise = 0.0, unsigned seed = 1) {
    std::vector<float> x(size_t(sr * secs));
    std::mt19937 rng(seed); std::normal_distribution<double> nd(0.0, 1.0);
    double ph = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        double s = 0.0;
        for (int h = 1; h <= 10; ++h) s += std::sin(h * ph) / h;
        x[i] = float(amp * s / 1.9 + noise * nd(rng));
        ph += 2.0 * kPi * f0 / sr;
    }
    return x;
}
static std::vector<float> voiceFm(double sr, double secs, double f0, double vibCents, double vibHz) {
    std::vector<float> x(size_t(sr * secs)); double ph = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        const double t = i / sr;
        const double f = f0 * std::exp2(vibCents / 1200.0 * std::sin(2 * kPi * vibHz * t));
        double s = 0.0; for (int h = 1; h <= 10; ++h) s += std::sin(h * ph) / h;
        x[i] = float(0.3 * s / 1.9); ph += 2.0 * kPi * f / sr;
    }
    return x;
}
static void run(Engine& e, std::vector<float>& L, std::vector<float>& R, int block) {
    for (size_t i = 0; i < L.size(); i += size_t(block)) {
        const int n = int(std::min<size_t>(size_t(block), L.size() - i));
        float* io[2] = { L.data() + i, R.data() + i };
        e.process(io, 2, n);
    }
}
// fundamental frequency of x[a,b) by scanning a fine DFT grid around `guess`
static double measureHz(const std::vector<float>& x, size_t a, size_t b, double sr, double guess) {
    const size_t N = b - a;
    std::vector<double> w(N);
    for (size_t i = 0; i < N; ++i) w[i] = 0.5 - 0.5 * std::cos(2 * kPi * i / (N - 1));
    auto mag = [&](double f) {
        double re = 0, im = 0, ph = 0, dph = 2 * kPi * f / sr;
        for (size_t i = 0; i < N; ++i) { re += w[i] * x[a + i] * std::cos(ph); im -= w[i] * x[a + i] * std::sin(ph); ph += dph; }
        return re * re + im * im;
    };
    double bestC = 0, bestM = -1; const double step = 1.0;
    for (double c = -100; c <= 100; c += step) { const double m = mag(guess * std::exp2(c / 1200)); if (m > bestM) { bestM = m; bestC = c; } }
    double lo = bestC - step, hi = bestC + step;
    for (int it = 0; it < 24; ++it) {            // golden-ish refinement
        const double m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3;
        if (mag(guess * std::exp2(m1 / 1200)) < mag(guess * std::exp2(m2 / 1200))) lo = m1; else hi = m2;
    }
    return guess * std::exp2(0.5 * (lo + hi) / 1200);
}
static double cents(double f, double ref) { return 1200.0 * std::log2(f / ref); }

// ---------------------------------------------------------------------------
static void test_latency() {
    std::printf("[latency] bit-exact delay when not shifting\n");
    const double rates[] = { 44100, 48000, 96000, 192000 };
    const double lats[]  = { 1.0, 2.5, 5.0, 10.0 };
    for (double sr : rates) for (double lm : lats) {
        Engine e; e.prepare(sr, 2);
        Params p; p.latencyMs = lm; e.setParams(p); e.reset();
        std::vector<float> L(8192, 0.f), R(8192, 0.f);
        L[100] = 1.f; R[200] = -0.5f;
        run(e, L, R, 64);
        const int lat = e.latencySamples();
        const int expect = int(std::lround(lm * 1e-3 * sr));
        size_t pk = 0; for (size_t i = 0; i < L.size(); ++i) if (std::fabs(L[i]) > std::fabs(L[pk])) pk = i;
        CHECK(lat == expect, "sr %.0f %.1fms: reported %d expected %d", sr, lm, lat, expect);
        CHECK(pk == size_t(100 + lat) && L[pk] == 1.f, "sr %.0f %.1fms: L impulse at %zu val %g (want %d)", sr, lm, pk, L[pk], 100 + lat);
        CHECK(R[200 + size_t(lat)] == -0.5f, "sr %.0f %.1fms: R impulse wrong", sr, lm);
    }
    std::printf("  2.5 ms @48k = %d samples\n", Engine().latencySamples());
}

static void test_accuracy() {
    std::printf("[accuracy] chromatic, A=440, hard tune; error in cents after settling\n");
    const double rates[] = { 44100, 48000, 96000 };
    const double bases[] = { 110.0, 164.81, 220.0, 329.63, 440.0, 659.26, 880.0 };
    const double dets[]  = { -40, -20, 15, 35 };
    double worst = 0;
    for (double sr : rates) for (double b : bases) for (double d : dets) {
        Engine e; e.prepare(sr, 2);
        Params p; p.retuneMs = 0; p.minHz = 70; e.setParams(p);
        auto L = voice(sr, 0.9, b * std::exp2(d / 1200.0), 0.3, 0.002);
        auto R = L;
        run(e, L, R, 256);
        const double f = measureHz(L, size_t(0.45 * sr), size_t(0.85 * sr), sr, b);
        const double err = cents(f, b);
        worst = std::max(worst, std::fabs(err));
        CHECK(std::fabs(err) < 4.0, "sr %.0f base %.1f det %+.0f -> out %.2f Hz (%+.2f c)", sr, b, d, f, err);
    }
    std::printf("  worst |error| = %.2f cents over %d cases\n", worst, 3 * 7 * 4);
}

static void test_scale() {
    std::printf("[scale] C major picks scale tones\n");
    Engine e; e.prepare(48000, 2);
    Params p; p.retuneMs = 0; p.mask = 0x0ab5; e.setParams(p);
    const double in = 220.0 * std::exp2(1.2 / 12.0);           // 1.2 st above A -> nearest scale tone is B
    auto L = voice(48000, 0.9, in, 0.3, 0.002); auto R = L; run(e, L, R, 128);
    const double f = measureHz(L, 21600, 40800, 48000, 246.94);
    CHECK(std::fabs(cents(f, 246.94)) < 4.0, "got %.2f Hz, wanted B3 246.94", f);
    std::printf("  1.2 st above A3 -> %.2f Hz (B3 = 246.94)\n", f);
}

static void test_blocksize() {
    std::printf("[blocks] output independent of host block size\n");
    auto src = voice(48000, 0.6, 233.0, 0.3, 0.003);
    std::vector<float> ref;
    for (int blk : { 1, 7, 64, 480, 4096 }) {
        Engine e; e.prepare(48000, 2); Params p; p.retuneMs = 30; e.setParams(p);
        auto L = src, R = src; run(e, L, R, blk);
        if (ref.empty()) ref = L;
        double md = 0; for (size_t i = 0; i < L.size(); ++i) md = std::max(md, double(std::fabs(L[i] - ref[i])));
        CHECK(md == 0.0, "block %d differs by %g", blk, md);
    }
}


// least-squares fit of a 10-harmonic series at the (measured) output f0; residual in dB.
// Any crossfade / jump artefact, aliasing or phase error shows up as residual.
static double harmonicResidualDb(const std::vector<float>& x, size_t a, size_t b, double sr, double f0) {
    const int H = 10, K = 2 * H; const size_t N = b - a;
    std::vector<double> M(size_t(K) * K, 0.0), v(K, 0.0), c(K);
    std::vector<double> basis(K);
    for (size_t i = 0; i < N; ++i) {
        const double ph = 2 * kPi * f0 * (a + i) / sr;
        for (int h = 1; h <= H; ++h) { basis[size_t(2 * h - 2)] = std::cos(h * ph); basis[size_t(2 * h - 1)] = std::sin(h * ph); }
        for (int r = 0; r < K; ++r) { v[size_t(r)] += basis[size_t(r)] * x[a + i]; for (int q = 0; q < K; ++q) M[size_t(r * K + q)] += basis[size_t(r)] * basis[size_t(q)]; }
    }
    for (int r = 0; r < K; ++r) {                       // Gaussian elimination
        int p = r; for (int q = r + 1; q < K; ++q) if (std::fabs(M[size_t(q * K + r)]) > std::fabs(M[size_t(p * K + r)])) p = q;
        for (int q = 0; q < K; ++q) std::swap(M[size_t(r * K + q)], M[size_t(p * K + q)]);
        std::swap(v[size_t(r)], v[size_t(p)]);
        for (int q = r + 1; q < K; ++q) { const double f = M[size_t(q * K + r)] / M[size_t(r * K + r)]; for (int k = r; k < K; ++k) M[size_t(q * K + k)] -= f * M[size_t(r * K + k)]; v[size_t(q)] -= f * v[size_t(r)]; }
    }
    for (int r = K - 1; r >= 0; --r) { double s = v[size_t(r)]; for (int k = r + 1; k < K; ++k) s -= M[size_t(r * K + k)] * c[size_t(k)]; c[size_t(r)] = s / M[size_t(r * K + r)]; }
    double es = 0, rs = 0;
    for (size_t i = 0; i < N; ++i) {
        const double ph = 2 * kPi * f0 * (a + i) / sr; double m = 0;
        for (int h = 1; h <= H; ++h) m += c[size_t(2 * h - 2)] * std::cos(h * ph) + c[size_t(2 * h - 1)] * std::sin(h * ph);
        const double r = x[a + i] - m; rs += r * r; es += double(x[a + i]) * x[a + i];
    }
    return 10 * std::log10(rs / es);
}

static void test_purity() {
    std::printf("[purity] harmonic-fit residual of corrected voice (lower is cleaner; input noise floor is about -33 dB)\n");
    double worst = -200;
    for (double b : { 110.0, 220.0, 440.0, 880.0 })
        for (double d : { -35.0, 20.0 }) {
            Engine e; e.prepare(48000, 2); Params p; p.retuneMs = 0; p.minHz = 70; e.setParams(p);
            auto L = voice(48000, 0.9, b * std::exp2(d / 1200.0), 0.3, 0.003); auto R = L; run(e, L, R, 256);
            const double f = measureHz(L, 21600, 40800, 48000, b);
            const double r = harmonicResidualDb(L, 21600, 40800, 48000, f);
            const double rin = [&] { auto Li = voice(48000, 0.9, b * std::exp2(d / 1200.0), 0.3, 0.003); return harmonicResidualDb(Li, 21600, 40800, 48000, measureHz(Li, 21600, 40800, 48000, b * std::exp2(d / 1200.0))); }();
            std::printf("  %4.0f Hz %+4.0fc : out %.1f dB   (input itself %.1f dB)\n", b, d, r, rin);
            worst = std::max(worst, r);
        }
    CHECK(worst < -26.0, "worst residual %.1f dB", worst);
}

static void test_glitch() {
    std::printf("[glitch] max sample step vs. clean tone (pure sine, +30c detune)\n");
    for (double f0 : { 110.0, 220.0, 440.0 }) {
        Engine e; e.prepare(48000, 2); Params p; p.retuneMs = 0; e.setParams(p);
        const double fin = f0 * std::exp2(30.0 / 1200);
        std::vector<float> L(48000); for (size_t i = 0; i < L.size(); ++i) L[i] = float(0.3 * std::sin(2 * kPi * fin * i / 48000.0));
        auto R = L; run(e, L, R, 128);
        double mx = 0; for (size_t i = 12000; i < L.size(); ++i) mx = std::max(mx, double(std::fabs(L[i] - L[i - 1])));
        const double ideal = 0.3 * 2 * kPi * f0 / 48000.0;
        std::printf("  %.0f Hz: max step / ideal = %.3f\n", f0, mx / ideal);
        CHECK(mx / ideal < 1.25, "%.0f Hz: step ratio %.3f", f0, mx / ideal);
    }
}

static void test_vibrato() {
    std::printf("[vibrato] +-45c @5.5Hz on A3, hard tune (retune 5 ms)\n");
    const double sr = 48000;
    Engine e; e.prepare(sr, 2); Params p; p.retuneMs = 5; e.setParams(p);
    auto L = voiceFm(sr, 2.5, 220.0, 45.0, 5.5); auto in = L; auto R = L; run(e, L, R, 256);
    auto dev = [&](const std::vector<float>& x) {
        double s = 0; int c = 0;
        for (size_t a = size_t(0.5 * sr); a + 2400 < x.size(); a += 2400) {
            const double f = measureHz(x, a, a + 2400, sr, 220.0); const double d = cents(f, 220.0); s += d * d; ++c;
        }
        return std::sqrt(s / c);
    };
    const double di = dev(in), dout = dev(L);
    std::printf("  rms deviation from A3: input %.1f c -> output %.1f c\n", di, dout);
    CHECK(dout < 0.45 * di, "vibrato not flattened enough (%.1f -> %.1f)", di, dout);
}


static double maxStep(const std::vector<float>& x, size_t a, size_t b) { double m = 0; for (size_t i = a + 1; i < b; ++i) m = std::max(m, double(std::fabs(x[i] - x[i - 1]))); return m; }

static void test_transitions() {
    std::printf("[transitions] glide across note boundaries; voice/silence/voice gaps (click check)\n");
    const double sr = 48000;
    {   // glide 200 -> 300 Hz over 1 s, C major, soft retune
        std::vector<float> L(size_t(sr * 1.5)); double ph = 0;
        for (size_t i = 0; i < L.size(); ++i) {
            const double t = i / sr, f = 200.0 * std::exp2(std::min(1.0, t / 1.0) * std::log2(1.5));
            double s = 0; for (int h = 1; h <= 8; ++h) s += std::sin(h * ph) / h; L[i] = float(0.3 * s / 1.9); ph += 2 * kPi * f / sr; }
        auto in = L, R = L; Engine e; e.prepare(sr, 2); Params p; p.mask = 0x0ab5; p.retuneMs = 30; e.setParams(p); run(e, L, R, 192);
        const double ri = maxStep(in, 12000, in.size()), ro = maxStep(L, 12000, L.size());
        std::printf("  glide: max step output/input = %.2f\n", ro / ri);
        CHECK(ro / ri < 1.6, "glide click: %.2f", ro / ri);
    }
    {   // gaps
        auto v = voice(sr, 0.4, 233.0, 0.3, 0.001); std::vector<float> L; L.insert(L.end(), v.begin(), v.end());
        L.insert(L.end(), size_t(sr * 0.25), 0.f); L.insert(L.end(), v.begin(), v.end());
        L.insert(L.end(), size_t(sr * 0.25), 0.f); L.insert(L.end(), v.begin(), v.end());
        auto in = L, R = L; Engine e; e.prepare(sr, 2); Params p; p.retuneMs = 10; e.setParams(p); run(e, L, R, 128);
        const double ri = maxStep(in, 0, in.size()), ro = maxStep(L, 0, L.size());
        std::printf("  gaps : max step output/input = %.2f\n", ro / ri);
        CHECK(ro / ri < 1.6, "gap click: %.2f", ro / ri);
        // after the last silence the output pitch must be corrected again
        const size_t s0 = L.size() - size_t(0.2 * sr);
        const double f = measureHz(L, s0, L.size(), sr, 233.08);
        std::printf("  gaps : 3rd phrase output %.2f Hz (A#3 = 233.08)\n", f);
        CHECK(std::fabs(cents(f, 233.08)) < 3.0, "3rd phrase %.2f Hz", f);
    }
}

static void test_robust() {
    std::printf("[robust] silence / NaN / Inf / DC / noise / mono\n");
    Engine e; e.prepare(48000, 2);
    std::vector<float> L(48000, 0.f), R(48000, 0.f);
    L[1000] = NAN; R[2000] = INFINITY; L[3000] = -INFINITY;
    for (size_t i = 20000; i < 30000; ++i) { L[i] = 0.5f; R[i] = 0.5f; }
    std::mt19937 rng(3); std::uniform_real_distribution<float> u(-0.3f, 0.3f);
    for (size_t i = 30000; i < 40000; ++i) { L[i] = u(rng); R[i] = u(rng); }
    run(e, L, R, 100);
    bool fin = true; for (size_t i = 0; i < L.size(); ++i) fin &= std::isfinite(L[i]) && std::isfinite(R[i]);
    CHECK(fin, "non-finite output");
    Engine m; m.prepare(44100, 1); std::vector<float> a(44100); for (size_t i = 0; i < a.size(); ++i) a[i] = float(0.3 * std::sin(2 * kPi * 200.0 * i / 44100.0));
    float* io[1] = { a.data() }; m.process(io, 1, int(a.size()));
    bool fin2 = true; for (float v : a) fin2 &= std::isfinite(v); CHECK(fin2, "mono non-finite");
    // noise must pass at ~unity level (no modulation / gain change)
    double ri = 0, ro = 0; Engine nz; nz.prepare(48000, 2);
    std::vector<float> N(48000), NR; for (auto& v : N) v = u(rng); NR = N; auto Nin = N; run(nz, N, NR, 256);
    for (size_t i = 12000; i < N.size(); ++i) { ri += double(Nin[i]) * Nin[i]; ro += double(N[i]) * N[i]; }
    std::printf("  noise level change: %.2f dB\n", 10 * std::log10(ro / ri));
    CHECK(std::fabs(10 * std::log10(ro / ri)) < 0.5, "noise level changed");
    // parameter abuse
    Engine pa; pa.prepare(48000, 2); Params q; q.mask = 0; q.refHz = -5; q.minHz = 1e9; q.latencyMs = -3; q.retuneMs = 1e9; q.amount = 9; pa.setParams(q);
    auto V = voice(48000, 0.3, 200.0); auto VR = V; run(pa, V, VR, 77);
    bool fin3 = true; for (float v : V) fin3 &= std::isfinite(v); CHECK(fin3, "param abuse non-finite");
}

static void test_delay_stats() {
    std::printf("[delay] where the shifted tonal content actually sits (samples @48k, reported = 120)\n");
    std::printf("  %-8s %-8s %6s %6s %6s   (ms: mean)\n", "f0 Hz", "detune", "min", "mean", "max");
    for (double f0 : { 110.0, 165.0, 220.0, 330.0, 440.0, 880.0 })
        for (double det : { 0.0, 25.0, -25.0 }) {
            Engine e; e.prepare(48000, 2); Params p; p.retuneMs = 0; p.minHz = 70; e.setParams(p);
            auto L = voice(48000, 3.0, f0 * std::exp2(det / 1200.0), 0.3, 0.002); auto R = L;
            double mn = 1e9, mx = 0, sum = 0; size_t cnt = 0;
            for (size_t i = 0; i < L.size(); i += 64) {
                float* io[2] = { L.data() + i, R.data() + i }; e.process(io, 2, 64);
                if (i > 24000) { const double d = e.currentDelay(); mn = std::min(mn, d); mx = std::max(mx, d); sum += d; ++cnt; }
            }
            std::printf("  %-8.0f %+-8.0f %6.0f %6.0f %6.0f   (%.2f ms)\n", f0, det, mn, sum / cnt, mx, sum / cnt / 48.0);
        }
}

static void test_cpu() {
    std::printf("[cpu] 60 s stereo voice with vibrato\n");
    for (double sr : { 48000.0, 96000.0 }) {
        auto L = voiceFm(sr, 60.0, 180.0, 60.0, 5.0); auto R = L;
        Engine e; e.prepare(sr, 2); Params p; p.minHz = 60; p.retuneMs = 15; e.setParams(p);
        const auto t0 = std::chrono::steady_clock::now();
        run(e, L, R, 512);
        const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        std::printf("  %.0f Hz: %.2f s for 60 s audio = %.2f %% of one core\n", sr, s, 100.0 * s / 60.0);
    }
}

int main(int argc, char** argv) {
    const bool quick = argc > 1 && std::string(argv[1]) == "--quick";
    test_latency(); test_accuracy(); test_scale(); test_blocksize(); test_glitch(); test_purity();
    test_vibrato(); test_transitions(); test_robust();
    if (!quick) { test_delay_stats(); test_cpu(); }
    std::printf(g_fail ? "\n%d FAILURES\n" : "\nALL PASSED\n", g_fail);
    return g_fail ? 1 : 0;
}
