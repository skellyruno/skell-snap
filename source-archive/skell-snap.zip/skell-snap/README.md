# Skell-Snap — low-latency pitch correction (VST3 / Standalone)

JUCE 8 / CMake plugin in the SKELL layout (company `Skell Audio`, manufacturer `SkAu`, plugin code `SkSn`,
bundle `audio.skell.snap`). The DSP lives in one header, `Source/dsp/SnapCore.h`, with no JUCE dependency.
It does not touch SkellyTune / SkellCore.

## Pipeline (the algorithm from the supplied notes, rebuilt)

1. **Scale table** – 7 octaves x 12 pitch classes (C1..B7), masked by the 12-bit scale mask; period =
   `sr / (ref * 2^((m-69)/12))`, validated `sr 8k-384k`, `ref 300-600`. Same constants as the original builder.
2. **Detector** – NSDF/MPM on a ~12 kHz decimated copy, then full-rate refinement around the winning lag.
   Adaptive window (~3.2 periods once locked), continuity prior against octave flips, voiced hysteresis.
3. **Snap** – nearest permitted note in log2 (binary search), with hysteresis so the target does not flutter.
4. **Retune** – exponential smoothing of the log-period error (`Retune` ms, 0 = hard tune), `Amount`,
   `Humanize` dead-band, and lead compensation so vibrato is tracked rather than lagged.
5. **Shifter** – two-head, period-synchronous delay line, 6-point Lagrange taps. Heads jump by exactly one
   input period with a correlation-aligned (sub-sample) crossfade.

## What was wrong in the pasted snippet (and is not carried over)

* the table was never built (`run()` gated on flags nothing sets first), so no note was ever targeted;
* the detector read a ring buffer as if linear (stale/scrambled audio);
* the crossfade counter reset the read pointers every ~period (glitch);
* shift ratio used the smoothed *target* period as the input period (ratio -> 1);
* the `|z|/(1+|z|)` smoother has a 1/t tail: ~1 s+ to get within 2 cents;
* delay was `2*pt + 8` plus up to one more period: ~30 ms at 100 Hz, not 2.5 ms.
The sentinel / dirty flags and the mirrored `Obj`/`Payload` byte layout were binary artefacts and are dropped.

## Latency — what is and is not guaranteed

Reported to the host: **2.5 ms** by default (120 samples @ 48k; choices 1 / 2.5 / 5 / 10 ms).
* Unvoiced, in-tune or unshifted audio is delayed by **exactly** that many samples (tested bit-exact at
  44.1/48/96/192 kHz and every latency setting).
* Voiced audio that is being shifted sits in a delay window one *input period* wide centred on that latency.
  That is the physical limit of period-synchronous shifting. Measured @48k (reported = 120):

| f0 | shifted delay min / mean / max |
|---|---|
| 880 Hz | 92 / 120 / 147 samples (2.5 ms mean) |
| 440 Hz | 64 / 119 / 175 |
| 220 Hz | 8 / 120–136 / 229–243 |
| 110 Hz | 6 / 227–251 / 449–466 (~5 ms mean) |

  So a voice above ~200 Hz stays within about +-1 ms of 2.5 ms; baritone/bass voices should use the 5 ms setting.
  Pitch *tracking* lag (~7-13 ms) is separate from audio latency and only affects how fast corrections start.
* Formants shift with the pitch (plain resampling). Fine for the usual +-50 cent corrections; large jumps
  will sound like a pitch-shifted voice. A formant-preserving mode would cost tens of ms.

## Measured here (`tests/test_snap.cpp`, synthetic harmonic voice; also clean under ASan + UBSan)

* Pitch accuracy: worst error **0.35 cents** over 84 cases (7 pitches x 4 detunes x 44.1/48/96 kHz), hard tune.
* Vibrato +-45 c @5.5 Hz: 30.7 -> 7.9 cents rms (retune 5 ms).
* Harmonic-fit residual of corrected output: at the input noise floor (-34 dB) from 110-440 Hz, -29..-32 dB at 880 Hz.
* Glide across note boundaries and voice/silence/voice gaps: max sample step <= 1.0x the input's.
* Output identical for block sizes 1..4096; survives NaN/Inf, DC, noise, silence, out-of-range parameters.
* CPU: ~1.0 % of one core @48k stereo, ~2.0 % @96k (Linux g++ -O2).

## Not verified — please read

* **The JUCE layer (`PluginProcessor`, `PluginEditor`, `CMakeLists.txt`) has not been compiled.** There was no
  JUCE or network in the build environment. It is written to the JUCE 8 API; expect to fix small compile errors.
* No real vocal recordings, no DAW host test (FL Studio/Reaper PDC, automation), no macOS/Windows build, no listening test.
* Standalone has no feedback protection. Use headphones.

## Build

```sh
cmake -S . -B build -DSNAP_BUILD_PLUGIN=OFF && cmake --build build && ./build/SnapCoreTests   # DSP only
cmake -S . -B build -DJUCE_PATH=/path/to/JUCE && cmake --build build --config Release         # plugin
```

## Provenance note

The pasted notes came from a disassembly (`RECON`, binary addresses). This code reuses only the generic
structure (period table, log2 snap, delay-line shifter) and is otherwise newly designed (standard MPM, Lagrange
taps, correlation-aligned jumps). If this ships commercially, keep a record of how it was derived.
