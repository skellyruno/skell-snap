#pragma once
#include <JuceHeader.h>
#include "dsp/SnapCore.h"

class SkellSnapAudioProcessor : public juce::AudioProcessor, private juce::AsyncUpdater {
public:
    SkellSnapAudioProcessor();
    ~SkellSnapAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int maxBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Skell-Snap"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    // UI helpers (message thread)
    snap::Telemetry telemetry() const { return engine_.telemetry(); }
    uint16_t effectiveMask() const;
    void toggleNote(int pitchClass);
    int  latencyReported() const { return reported_; }

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    snap::Params readParams() const;
    void handleAsyncUpdate() override { setLatencySamples(pending_.load()); }
    void setBool(const juce::String& id, bool v);

    snap::Engine engine_;
    std::atomic<float> *pKey = nullptr, *pScale = nullptr, *pRef = nullptr, *pRetune = nullptr,
                       *pAmount = nullptr, *pHuman = nullptr, *pMinHz = nullptr, *pLat = nullptr;
    std::atomic<float>* pNote[12] {};
    int reported_ = 0;
    std::atomic<int> pending_ { 0 };
    static constexpr double kLat[4] = { 1.0, 2.5, 5.0, 10.0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SkellSnapAudioProcessor)
};
