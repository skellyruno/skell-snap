#pragma once
// SnapCore.h - Skell-Snap low-latency pitch-correction engine.
// Header-only, C++17, no JUCE, no allocation after prepare().
//
// Signal flow
//   input -> ring buffers (per channel + mono sum)
//   mono  -> FIR decimator (~12 kHz) -> MPM/NSDF detector -> full-rate refine
//   period -> scale-table snap (log2 domain, hysteresis) -> retune smoother
//   ratio  -> two-head, period-synchronous delay-line shifter (cubic taps,
//             correlation-aligned jumps of exactly one input period)
//
// Latency contract
//   * Unvoiced / in-tune / bypassed-correction audio is delayed by EXACTLY
//     latencySamples() (bit-exact integer delay).
//   * Voiced audio that is being shifted lives in a delay window one input
//     period wide, centred on that latency (or starting at a 6-sample floor
//     for periods longer than 2x the latency).  See README "Latency".
#include <algorithm>
#include <atomic>
#include <cfloat>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace snap {

constexpr double kPi          = 3.14159265358979323846;
// the table-builder constants of the original algorithm, unchanged
constexpr double kSemisPerOct = 12.0;
constexpr double kNoteBias    = 24.0;   // lowest table note (C1)
constexpr double kRefNote     = 69.0;   // A4
constexpr double kSrMin       = 8000.0;
constexpr double kSrMax       = 384000.0;
constexpr double kRefMin      = 300.0;
constexpr double kRefMax      = 600.0;
constexpr int    kOctaves     = 7;
constexpr int    kSemis       = 12;
constexpr int    kMaxEntry    = kOctaves * kSemis;   // 84

// --------------------------------------------------------------------------
// Scale table: periods (in samples) of every permitted note, descending.
// Same maths as the original builder: period = sr / (ref * 2^((m-69)/12)).
// --------------------------------------------------------------------------
struct ScaleTable {
    int    count = 0;
    double lgPeriod[kMaxEntry] {};
    double period[kMaxEntry] {};
    int    note[kMaxEntry] {};

    bool build(double sr, double ref, uint16_t mask) noexcept {
        if (!(sr >= kSrMin && sr <= kSrMax)) return false;     // also rejects NaN
        if (!(ref >= kRefMin && ref <= kRefMax)) return false;
        mask &= 0x0fff;
        if (mask == 0) mask = 0x0fff;                          // never empty
        int n = 0;
        for (int oct = 0; oct < kOctaves; ++oct)
            for (int semi = 0; semi < kSemis; ++semi) {
                if (!((mask >> semi) & 1u)) continue;
                const int m = int(kNoteBias) + oct * kSemis + semi;
                const double e = (double(m) - kRefNote) / kSemisPerOct;
                const double v = sr / (std::exp2(e) * ref);
                period[n] = v; lgPeriod[n] = std::log2(v); note[n] = m; ++n;
            }
        count = n;
        return true;
    }

    // nearest note in log2 (descending table); hysteresis keeps the previous
    // note unless the new one is closer by more than `hyst` octaves.
    int nearest(double lg, int prev, double hyst) const noexcept {
        if (count <= 0) return -1;
        int lo = 0, hi = count;
        while (lo < hi) {
            const int mid = (lo + hi) >> 1;
            if (lgPeriod[mid] > lg) lo = mid + 1; else hi = mid;
        }
        int best;
        if (lo == 0) best = 0;
        else if (lo == count) best = count - 1;
        else best = (lgPeriod[lo - 1] - lg) < (lg - lgPeriod[lo]) ? lo - 1 : lo;
        if (prev >= 0 && prev < count && prev != best &&
            std::fabs(lgPeriod[prev] - lg) <= std::fabs(lgPeriod[best] - lg) + hyst)
            best = prev;
        return best;
    }
};

// --------------------------------------------------------------------------
// Period detector: McLeod-style NSDF on a ~12 kHz decimated copy (cheap),
// followed by a full-rate refinement around the winning lag.
// --------------------------------------------------------------------------
class Detector {
public:
    static constexpr double kMinHzAbs = 40.0;     // allocation floor
    static constexpr double kMaxHz    = 1400.0;   // detection ceiling

    void prepare(double sr) {
        sr_ = sr;
        D_ = std::max(1, int(std::floor(sr / 12000.0)));
        fsd_ = sr / D_;
        tmin_ = std::max(2, int(std::floor(fsd_ / kMaxHz)));
        tmaxCap_ = int(std::ceil(fsd_ / kMinHzAbs)) + 2;
        wCap_ = 2 * tmaxCap_ + 8;
        nsdf_.assign(size_t(tmaxCap_ + 3), 0.0);
        win_.assign(size_t(wCap_), 0.0);
        pre_.assign(size_t(wCap_ + 1), 0.0);
        lobeI_.assign(size_t(tmaxCap_ / 2 + 4), 0);
        lobeV_.assign(size_t(tmaxCap_ / 2 + 4), 0.0);
        size_t ds = 1; while (int(ds) < wCap_ + 16) ds <<= 1;
        dec_.assign(ds, 0.f); dmask_ = ds - 1;
        ntaps_ = D_ > 1 ? 8 * D_ + 1 : 1;
        fir_.assign(size_t(ntaps_), 0.0);
        if (D_ > 1) {                                   // Blackman-windowed sinc
            const double fc = 0.42 / D_;
            const int M = (ntaps_ - 1) / 2;
            double sum = 0.0;
            for (int k = 0; k < ntaps_; ++k) {
                const double x = double(k - M);
                const double s = (k == M) ? 2.0 * fc : std::sin(2.0 * kPi * fc * x) / (kPi * x);
                const double w = 0.42 - 0.5 * std::cos(2.0 * kPi * k / (ntaps_ - 1))
                                      + 0.08 * std::cos(4.0 * kPi * k / (ntaps_ - 1));
                fir_[size_t(k)] = s * w; sum += s * w;
            }
            for (auto& h : fir_) h /= sum;
        }
        reset();
        setMinHz(80.0);
    }
    void reset() noexcept { decW_ = 0; phase_ = 0; std::fill(dec_.begin(), dec_.end(), 0.f); }
    void setMinHz(double hz) noexcept {
        minHz_ = std::min(400.0, std::max(kMinHzAbs, hz));
        tmax_ = std::min(tmaxCap_, int(std::ceil(fsd_ / minHz_)));
        W_ = 2 * tmax_ + 8;
    }
    int decimation() const noexcept { return D_; }
    // full-rate samples spanned by the last analysis window
    int lastWindow() const noexcept { return lastW_ * D_; }

    // call once per input sample, after mono[n] has been written
    void feed(const float* mono, uint64_t mmask, int64_t n) noexcept {
        if (++phase_ < D_) return;
        phase_ = 0;
        double y;
        if (D_ == 1) y = mono[uint64_t(n) & mmask];
        else {
            y = 0.0;
            for (int k = 0; k < ntaps_; ++k)
                y += fir_[size_t(k)] * mono[uint64_t(n - k) & mmask];
        }
        dec_[decW_ & dmask_] = float(y);
        ++decW_;
    }

    // returns true and P (full-rate samples, fractional) + conf when a period exists
    bool detect(const float* mono, uint64_t mmask, int64_t n, double prevP,
                double& P, double& conf) noexcept {
        P = 0.0; conf = 0.0;
        // once a pitch is being tracked, only look ~1.6 periods deep: a shorter
        // window means less tracking lag (and less CPU) for higher voices
        int tmax = tmax_;
        if (prevP > 0.0)
            tmax = std::max(std::min(tmax_, tmin_ + 6), std::min(tmax_, int(std::ceil(1.6 * prevP / D_))));
        const int W = 2 * tmax + 8;
        lastW_ = W;
        if (decW_ < uint64_t(W)) return false;
        for (int i = 0; i < W; ++i)
            win_[size_t(i)] = dec_[(decW_ - uint64_t(W) + uint64_t(i)) & dmask_];
        pre_[0] = 0.0;
        for (int i = 0; i < W; ++i) pre_[size_t(i + 1)] = pre_[size_t(i)] + win_[size_t(i)] * win_[size_t(i)];
        if (pre_[size_t(W)] / W < 1e-7) return false;           // ~ -70 dBFS gate

        const double* w = win_.data();
        for (int t = 1; t <= tmax + 1; ++t) {
            double acf = 0.0;
            const int cnt = W - t;
            for (int i = 0; i < cnt; ++i) acf += w[i] * w[i + t];
            const double m = pre_[size_t(W - t)] + (pre_[size_t(W)] - pre_[size_t(t)]);
            nsdf_[size_t(t)] = m > 1e-12 ? 2.0 * acf / m : 0.0;
        }
        // key maxima: one per positive lobe, after the lag-0 lobe
        int t = 1;
        while (t <= tmax && nsdf_[size_t(t)] > 0.0) ++t;
        int nl = 0;
        const int lobeCap = int(lobeI_.size());
        while (t <= tmax) {
            while (t <= tmax && nsdf_[size_t(t)] <= 0.0) ++t;
            if (t > tmax) break;
            int bi = t;
            while (t <= tmax && nsdf_[size_t(t)] > 0.0) {
                if (nsdf_[size_t(t)] > nsdf_[size_t(bi)]) bi = t;
                ++t;
            }
            if (bi >= tmin_ && bi <= tmax && nl < lobeCap) {
                lobeI_[size_t(nl)] = bi; lobeV_[size_t(nl)] = nsdf_[size_t(bi)]; ++nl;
            }
        }
        if (nl == 0) return false;
        double kmax = 0.0;
        for (int l = 0; l < nl; ++l) kmax = std::max(kmax, lobeV_[size_t(l)]);
        if (kmax < 0.3) return false;
        int c = 0;
        while (c < nl - 1 && lobeV_[size_t(c)] < 0.9 * kmax) ++c;
        if (prevP > 0.0) {                       // continuity prior against octave flips
            const double prevD = prevP / D_;
            int bl = -1; double bd = 1e9;
            for (int l = 0; l < nl; ++l) {
                const double d = std::fabs(std::log(double(lobeI_[size_t(l)]) / prevD));
                if (d < bd) { bd = d; bl = l; }
            }
            if (bl >= 0 && bd < 0.06 && lobeV_[size_t(bl)] >= 0.8 * lobeV_[size_t(c)]) c = bl;
        }
        double val;
        const double pd = refine(nsdf_.data(), lobeI_[size_t(c)], val);
        double pf = pd * D_;
        double cf = std::min(1.0, std::max(0.0, val));

        if (D_ > 1) {                            // full-rate refinement around pf
            const int Wf = std::min(int(2.5 * pf) + 8, int(mmask / 4));
            const int lo = std::max(2, int(std::floor(pf)) - D_ - 1);
            const int hi = int(std::ceil(pf)) + D_ + 1;
            const int nlag = hi - lo + 1;
            if (nlag <= int(fnsdf_.size())) {
                for (int L = lo; L <= hi; ++L) {
                    double acf = 0.0, m = 0.0;
                    for (int i = 0; i < Wf; ++i) {
                        const double a = mono[uint64_t(n - i) & mmask];
                        const double b = mono[uint64_t(n - i - L) & mmask];
                        acf += a * b; m += a * a + b * b;
                    }
                    fnsdf_[size_t(L - lo)] = m > 1e-12 ? 2.0 * acf / m : 0.0;
                }
                int bi = 0;
                for (int k = 1; k < nlag; ++k) if (fnsdf_[size_t(k)] > fnsdf_[size_t(bi)]) bi = k;
                if (bi > 0 && bi < nlag - 1 && fnsdf_[size_t(bi)] > 0.3) {
                    double v2;
                    pf = lo + refine(fnsdf_.data(), bi, v2);
                    cf = std::min(1.0, std::max(0.0, v2));
                }
            }
        }
        P = pf; conf = cf;
        return pf > 1.0;
    }

    void allocateRefine() { fnsdf_.assign(size_t(2 * D_ + 8), 0.0); }

private:
    static double refine(const double* v, int idx, double& peak) noexcept {
        const double a = v[idx - 1], b = v[idx], c = v[idx + 1];
        const double den = a - 2.0 * b + c;
        double sh = 0.0;
        if (den < -1e-12) sh = std::min(1.0, std::max(-1.0, 0.5 * (a - c) / den));
        peak = b - 0.25 * (a - c) * sh;
        return idx + sh;
    }
    double sr_ = 48000.0, fsd_ = 12000.0, minHz_ = 80.0;
    int D_ = 4, tmin_ = 8, tmax_ = 150, tmaxCap_ = 302, W_ = 308, wCap_ = 612, ntaps_ = 33, lastW_ = 308;
    uint64_t decW_ = 0, dmask_ = 0; int phase_ = 0;
    std::vector<double> nsdf_, win_, pre_, fir_, lobeV_, fnsdf_;
    std::vector<int> lobeI_;
    std::vector<float> dec_;
};

// --------------------------------------------------------------------------
struct Params {
    uint16_t mask      = 0x0fff;   // 12 pitch classes, bit0 = C
    double   refHz     = 440.0;
    double   retuneMs  = 25.0;     // 0 = instant (hard tune)
    double   amount    = 1.0;      // 0..1 fraction of the correction applied
    double   humanize  = 0.0;      // cents of dead-band around each note
    double   minHz     = 80.0;     // lowest pitch the detector looks for
    double   latencyMs = 2.5;      // reported / bit-exact latency
};

struct Telemetry {
    float inHz = 0.f, targetHz = 0.f, cents = 0.f, conf = 0.f;
    int   targetNote = -1;
    bool  voiced = false;
};

class Engine {
public:
    static constexpr double kEnter = 0.55, kExit = 0.40, kHoldSec = 0.040;
    static constexpr double kFloor = 6.0;    // smallest tap delay ever used

    void prepare(double sr, int channels) {
        sr_ = std::min(kSrMax, std::max(kSrMin, sr));
        ch_ = std::min(2, std::max(1, channels));
        det_.prepare(sr_);
        det_.allocateRefine();
        const int D = det_.decimation();
        hop_ = std::max(D, int(std::lround(sr_ * 0.0027 / D)) * D);
        maxLx_ = std::max(32, int(std::lround(0.0025 * sr_)));
        minLx_ = std::max(8, int(std::lround(0.0004 * sr_)));
        maxP_  = sr_ / Detector::kMinHzAbs;
        const double need = std::max(0.020 * sr_ + 3.5 * maxP_ + 4.0 * maxLx_ + 64.0,
                                     4.0 * maxP_ + 64.0);
        size_t rs = 1; while (double(rs) < need) rs <<= 1;
        for (int c = 0; c < 2; ++c) ring_[c].assign(rs, 0.f);
        mono_.assign(rs, 0.f);
        mask_ = rs - 1;
        sc_.assign(size_t(2 * (std::max(2, int(std::lround(0.06 * maxP_))) + 2) + 3), 0.0);
        dMax_ = double(rs) - 8.0 - 2.0 * maxLx_;
        rCoef_ = 1.0 - std::exp(-1.0 / (0.003 * sr_));
        params_ = Params{};
        tableKey_ = 0xffffffffu; refKey_ = -1.0;
        applyParams(params_, true);
        reset();
    }

    void reset() noexcept {
        for (int c = 0; c < 2; ++c) std::fill(ring_[c].begin(), ring_[c].end(), 0.f);
        std::fill(mono_.begin(), mono_.end(), 0.f);
        det_.reset();
        n_ = 0; hopCount_ = 0;
        A_ = home_; B_ = home_; fading_ = false; fadePos_ = fadeLen_ = 0;
        r_ = rTarget_ = 1.0; eSm_ = 0.0;
        Pcur_ = lastGoodP_ = 0.0; periodValid_ = voiced_ = false; heldHops_ = 0;
        prevIdx_ = -1; forceHome_ = false; histPos_ = histN_ = 0; slope_ = 0.0;
        tInHz_ = tTgtHz_ = tCents_ = tConf_ = 0.f; tNote_ = -1; tVoiced_ = false;
    }

    void setParams(const Params& p) noexcept { applyParams(p, false); }
    int  latencySamples() const noexcept { return lat_; }
    double currentDelay() const noexcept { return A_; }   // diagnostics
    double currentRatio() const noexcept { return r_; }

    Telemetry telemetry() const noexcept {
        Telemetry t;
        t.inHz = tInHz_.load(std::memory_order_relaxed);
        t.targetHz = tTgtHz_.load(std::memory_order_relaxed);
        t.cents = tCents_.load(std::memory_order_relaxed);
        t.conf = tConf_.load(std::memory_order_relaxed);
        t.targetNote = tNote_.load(std::memory_order_relaxed);
        t.voiced = tVoiced_.load(std::memory_order_relaxed);
        return t;
    }

    // in-place; any block size (processing is strictly per-sample)
    void process(float* const* io, int nch, int frames) noexcept {
        nch = std::min(nch, ch_);
        if (nch <= 0) return;
        const float invN = 1.0f / float(nch);
        for (int i = 0; i < frames; ++i) {
            const int64_t n = n_;
            const uint64_t wi = uint64_t(n) & mask_;
            float m = 0.f;
            for (int c = 0; c < nch; ++c) {
                float x = io[c][i];
                if (!std::isfinite(x)) x = 0.f;
                ring_[c][wi] = x; m += x;
            }
            mono_[wi] = m * invN;
            det_.feed(mono_.data(), mask_, n);
            if (++hopCount_ >= hop_) { hopCount_ = 0; analyse(n); }
            step(n);
            const double g = fading_ ? 0.5 - 0.5 * std::cos(kPi * (fadePos_ + 1.0) / (fadeLen_ + 1.0)) : 0.0;
            for (int c = 0; c < nch; ++c) {
                const float a = tap(ring_[c].data(), A_, n);
                float y = a;
                if (fading_) { const float b = tap(ring_[c].data(), B_, n); y = a + (b - a) * float(g); }
                io[c][i] = y;
            }
            ++n_;
        }
    }

private:
    void applyParams(const Params& p, bool force) noexcept {
        const double ref = std::min(kRefMax, std::max(kRefMin, p.refHz));
        const uint16_t mk = uint16_t(p.mask & 0x0fff) ? uint16_t(p.mask & 0x0fff) : uint16_t(0x0fff);
        const uint32_t key = mk;
        if (force || key != tableKey_ || ref != refKey_) {
            if (table_.build(sr_, ref, mk)) { tableKey_ = key; refKey_ = ref; prevIdx_ = -1; }
        }
        params_ = p;
        params_.refHz = ref;
        params_.amount = std::min(1.0, std::max(0.0, p.amount));
        params_.humanize = std::min(100.0, std::max(0.0, p.humanize));
        det_.setMinHz(p.minHz);
        const double dt = hop_ / sr_;
        const double ms = std::max(0.0, p.retuneMs);
        alpha_ = ms < 0.5 ? 1.0 : 1.0 - std::exp(-dt / (ms * 1e-3));
        unvAlpha_ = 1.0 - std::exp(-dt / 0.015);
        const int lat = int(std::lround(std::min(20.0, std::max(0.5, p.latencyMs)) * 1e-3 * sr_));
        const int latC = std::max(int(kFloor) + 2, lat);
        if (latC != lat_) {
            lat_ = latC;
            if (double(lat_) != home_) { home_ = double(lat_); forceHome_ = true; }
        }
    }

    // 6-point (5th-order) Lagrange fractional-delay tap: flat to ~0.2*fs, and
    // exactly the stored sample at integer delays (keeps the latency bit-exact)
    float tapAt(const float* r, double d, int64_t n) const noexcept {
        d = d < 4.0 ? 4.0 : (d > double(mask_ - 8) ? double(mask_ - 8) : d);
        const double p = double(n) - d;
        const double fl = std::floor(p);
        const int64_t i0 = int64_t(fl);
        const float t = float(p - fl);
        const float A = t + 2.f, B = t + 1.f, C = t, D = t - 1.f, E = t - 2.f, F = t - 3.f;
        const float w0 = B * C * D * E * F * (-1.f / 120.f);
        const float w1 = A * C * D * E * F * (1.f / 24.f);
        const float w2 = A * B * D * E * F * (-1.f / 12.f);
        const float w3 = A * B * C * E * F * (1.f / 12.f);
        const float w4 = A * B * C * D * F * (-1.f / 24.f);
        const float w5 = A * B * C * D * E * (1.f / 120.f);
        const uint64_t u = uint64_t(i0);
        return w0 * r[(u - 2) & mask_] + w1 * r[(u - 1) & mask_] + w2 * r[u & mask_] +
               w3 * r[(u + 1) & mask_] + w4 * r[(u + 2) & mask_] + w5 * r[(u + 3) & mask_];
    }
    float tap(const float* r, double d, int64_t n) const noexcept { return tapAt(r, d, n); }

    void analyse(int64_t n) noexcept {
        double P = 0.0, conf = 0.0;
        const bool ok = det_.detect(mono_.data(), mask_, n, lastGoodP_, P, conf);
        const bool v = ok && (voiced_ ? conf >= kExit : conf >= kEnter) &&
                       P >= sr_ / 1500.0 && P <= maxP_;
        const double dt = hop_ / sr_;
        if (v && table_.count > 0) {
            voiced_ = true; heldHops_ = 0; periodValid_ = true;
            Pcur_ = lastGoodP_ = P;
            const double lgMeas = std::log2(P);
            // the analysis window is centred ~W/2 samples in the past: extrapolate
            // the (smoothed) log-period slope to "now" so vibrato is tracked, not lagged
            if (histN_ >= 3) {
                const double sl = (lgMeas - lgHist_[(histPos_ + 1) & 3]) / 3.0;   // oct / hop
                slope_ += 0.35 * (sl - slope_);
            } else slope_ = 0.0;
            lgHist_[histPos_ & 3] = lgMeas; ++histPos_; ++histN_;
            const double leadHops = 0.5 * det_.lastWindow() / double(hop_);
            const double lead = std::min(0.03, std::max(-0.03, slope_ * leadHops));
            const double lg = lgMeas + lead;
            const int idx = table_.nearest(lg, prevIdx_, 0.015);
            prevIdx_ = idx;
            double e = table_.lgPeriod[idx] - lg;          // octaves; + = input is sharp
            const double eRaw = e;
            if (std::fabs(e) > 0.5) e = 0.0;
            e *= params_.amount;
            const double tol = params_.humanize / 1200.0, a = std::fabs(e);
            e = a <= tol ? 0.0 : std::copysign(a - tol, e);
            eSm_ += alpha_ * (e - eSm_);
            tInHz_ = float(sr_ / P); tTgtHz_ = float(sr_ / table_.period[idx]);
            tCents_ = float(eRaw * 1200.0); tConf_ = float(conf);
            tNote_ = table_.note[idx]; tVoiced_ = true;
        } else {
            voiced_ = false;
            ++heldHops_;
            if (heldHops_ * dt > kHoldSec) {
                periodValid_ = false; lastGoodP_ = 0.0; prevIdx_ = -1; histN_ = 0; slope_ = 0.0;
                eSm_ += unvAlpha_ * (0.0 - eSm_);
                tVoiced_ = false; tNote_ = -1; tConf_ = float(conf);
            }
        }
        rTarget_ = std::exp2(-eSm_);
    }

    void step(int64_t n) noexcept {
        r_ += rCoef_ * (rTarget_ - r_);
        const double drift = 1.0 - r_;
        A_ += drift;
        if (fading_) {
            B_ += drift;
            if (++fadePos_ >= fadeLen_) { A_ = B_; fading_ = false; }
        }
        if (fading_) return;
        const double P = Pcur_;
        if (forceHome_) { startJump(n, home_ - A_, false); return; }
        if (periodValid_ && P >= sr_ / 1500.0) {
            const double lo = std::max(kFloor + std::fabs(r_ - 1.0) * maxLx_, home_ - 0.5 * P);
            // guard band = alignment-search radius, so a +P jump that lands a few
            // samples long can never immediately trigger a -P jump (ping-pong)
            const double hi = lo + P + std::max(2, int(std::lround(0.06 * P))) + 1.0;
            if (A_ < lo) startJump(n, +P, true);
            else if (A_ > hi) startJump(n, -P, true);
        } else if (std::fabs(A_ - home_) > 0.5) {
            startJump(n, home_ - A_, false);
        }
        if (!fading_ && (A_ < kFloor || A_ > dMax_)) startJump(n, home_ - A_, false);
    }

    // begin a crossfaded jump of the read head by `delta` samples (+ = older)
    void startJump(int64_t n, double delta, bool align) noexcept {
        double dB = A_ + delta;
        int Lx = maxLx_;
        if (align) {
            Lx = std::min(maxLx_, std::max(minLx_, int(std::lround(0.5 * Pcur_))));
            const int S = std::max(2, int(std::lround(0.06 * Pcur_)));
            const int ia = int(std::lround(A_));
            // correlate over ~2 periods (not just the fade): sharper peak, better sub-sample lag
            const int Lc = std::max(Lx, std::min(int(std::lround(2.0 * Pcur_)), 4 * maxLx_));
            double aa = 1e-9;
            for (int j = 1; j <= Lc; ++j) {
                const double a = mono_[uint64_t(n - ia - j) & mask_]; aa += a * a;
            }
            // candidates are integer lags around ia + round(delta); correlate what A
            // just played against what each candidate head would have played, then
            // refine the winner to sub-sample resolution (parabolic interpolation)
            const int ib0 = ia + int(std::lround(delta));
            int bk = 0; double best = 0.2; bool any = false;
            const int cnt = 2 * S + 1;
            for (int k = -S; k <= S; ++k) {
                const int ib = ib0 + k;
                double sc = -1.0;
                if (ib >= int(kFloor) + 1 && double(ib) <= dMax_ && double(ib + Lc) < double(mask_) - 8.0) {
                    double ab = 0.0, bb = 1e-9;
                    for (int j = 1; j <= Lc; ++j) {
                        const double a = mono_[uint64_t(n - ia - j) & mask_];
                        const double b = mono_[uint64_t(n - ib - j) & mask_];
                        ab += a * b; bb += b * b;
                    }
                    sc = ab / std::sqrt(aa * bb);
                }
                sc_[size_t(k + S)] = sc;
                if (sc > best) { best = sc; bk = k; any = true; }
            }
            if (any) {
                double frac = 0.0;
                const int ki = bk + S;
                if (ki > 0 && ki < cnt - 1 && sc_[size_t(ki - 1)] > -0.5 && sc_[size_t(ki + 1)] > -0.5) {
                    const double y0 = sc_[size_t(ki - 1)], y1 = sc_[size_t(ki)], y2 = sc_[size_t(ki + 1)];
                    const double den = y0 - 2.0 * y1 + y2;
                    if (den < -1e-12) frac = std::min(0.5, std::max(-0.5, 0.5 * (y0 - y2) / den));
                }
                // lag found = (ib0 + bk + frac) - ia relative to A's integer position;
                // express it relative to A's true fractional position
                dB = A_ + double(ib0 + bk - ia) + frac;
            }
        }
        const double lo = kFloor + std::fabs(r_ - 1.0) * Lx;
        dB = std::min(dMax_, std::max(lo, dB));
        if (std::fabs(dB - A_) < 1e-9) { forceHome_ = false; return; }
        B_ = dB; fadeLen_ = Lx; fadePos_ = 0; fading_ = true; forceHome_ = false;
    }

    // --- state ---
    double sr_ = 48000.0; int ch_ = 2;
    Detector det_; ScaleTable table_; Params params_;
    uint32_t tableKey_ = 0xffffffffu; double refKey_ = -1.0;
    std::vector<float> ring_[2], mono_;
    std::vector<double> sc_;
    uint64_t mask_ = 0; double dMax_ = 0.0;
    int64_t n_ = 0; int hop_ = 128, hopCount_ = 0, maxLx_ = 120, minLx_ = 19, lat_ = 120;
    double maxP_ = 1200.0, home_ = 120.0;
    double A_ = 120.0, B_ = 120.0; bool fading_ = false; int fadePos_ = 0, fadeLen_ = 0;
    double r_ = 1.0, rTarget_ = 1.0, rCoef_ = 0.0, eSm_ = 0.0, alpha_ = 1.0, unvAlpha_ = 0.1;
    double Pcur_ = 0.0, lastGoodP_ = 0.0; bool periodValid_ = false, voiced_ = false;
    int heldHops_ = 0, prevIdx_ = -1; bool forceHome_ = false;
    double lgHist_[4] {}, slope_ = 0.0; int histPos_ = 0, histN_ = 0;
    std::atomic<float> tInHz_ {0.f}, tTgtHz_ {0.f}, tCents_ {0.f}, tConf_ {0.f};
    std::atomic<int> tNote_ {-1}; std::atomic<bool> tVoiced_ {false};
};

} // namespace snap
