#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace {
uint16_t rotate12(unsigned pattern, int root) {
    const unsigned r = unsigned(((root % 12) + 12) % 12);
    return uint16_t(((pattern << r) | (pattern >> (12u - r))) & 0x0fffu);
}
constexpr unsigned kPatterns[5] = { 0x0fff, 0x0ab5, 0x05ad, 0x0295, 0x04a9 };  // chrom, maj, min, majPent, minPent
}

SkellSnapAudioProcessor::SkellSnapAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "SkellSnap", createLayout())
{
    pKey = apvts.getRawParameterValue("key");        pScale = apvts.getRawParameterValue("scale");
    pRef = apvts.getRawParameterValue("ref");        pRetune = apvts.getRawParameterValue("retune");
    pAmount = apvts.getRawParameterValue("amount");  pHuman = apvts.getRawParameterValue("humanize");
    pMinHz = apvts.getRawParameterValue("minhz");    pLat = apvts.getRawParameterValue("latency");
    for (int i = 0; i < 12; ++i) pNote[i] = apvts.getRawParameterValue("n" + juce::String(i));
}

juce::AudioProcessorValueTreeState::ParameterLayout SkellSnapAudioProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout l;
    l.add(std::make_unique<AudioParameterChoice>(ParameterID{ "key", 1 }, "Key",
          StringArray{ "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 0));
    l.add(std::make_unique<AudioParameterChoice>(ParameterID{ "scale", 1 }, "Scale",
          StringArray{ "Chromatic", "Major", "Minor", "Major Pentatonic", "Minor Pentatonic", "Custom" }, 0));
    static const char* names[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    for (int i = 0; i < 12; ++i)
        l.add(std::make_unique<AudioParameterBool>(ParameterID{ "n" + String(i), 1 }, String("Note ") + names[i], true));
    l.add(std::make_unique<AudioParameterFloat>(ParameterID{ "ref", 1 }, "Reference A4",
          NormalisableRange<float>(400.0f, 480.0f, 0.1f), 440.0f, AudioParameterFloatAttributes().withLabel("Hz")));
    l.add(std::make_unique<AudioParameterFloat>(ParameterID{ "retune", 1 }, "Retune Speed",
          NormalisableRange<float>(0.0f, 500.0f, 0.1f, 0.4f), 25.0f, AudioParameterFloatAttributes().withLabel("ms")));
    l.add(std::make_unique<AudioParameterFloat>(ParameterID{ "amount", 1 }, "Amount",
          NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f, AudioParameterFloatAttributes().withLabel("%")));
    l.add(std::make_unique<AudioParameterFloat>(ParameterID{ "humanize", 1 }, "Humanize",
          NormalisableRange<float>(0.0f, 60.0f, 0.1f), 0.0f, AudioParameterFloatAttributes().withLabel("cents")));
    l.add(std::make_unique<AudioParameterFloat>(ParameterID{ "minhz", 1 }, "Lowest Pitch",
          NormalisableRange<float>(40.0f, 400.0f, 1.0f, 0.5f), 80.0f, AudioParameterFloatAttributes().withLabel("Hz")));
    l.add(std::make_unique<AudioParameterChoice>(ParameterID{ "latency", 1 }, "Latency",
          StringArray{ "1 ms (Ultra)", "2.5 ms (Low)", "5 ms (Bass / Baritone)", "10 ms (Stable)" }, 1));
    return l;
}

uint16_t SkellSnapAudioProcessor::effectiveMask() const
{
    const int scale = int(pScale->load() + 0.5f), key = int(pKey->load() + 0.5f);
    if (scale >= 0 && scale < 5) return rotate12(kPatterns[scale], key);
    unsigned m = 0;
    for (int i = 0; i < 12; ++i) if (pNote[i]->load() > 0.5f) m |= 1u << i;
    return m ? uint16_t(m) : uint16_t(0x0fff);
}

snap::Params SkellSnapAudioProcessor::readParams() const
{
    snap::Params p;
    p.mask = effectiveMask();
    p.refHz = pRef->load();
    p.retuneMs = pRetune->load();
    p.amount = double(pAmount->load()) * 0.01;
    p.humanize = pHuman->load();
    p.minHz = pMinHz->load();
    p.latencyMs = kLat[juce::jlimit(0, 3, int(pLat->load() + 0.5f))];
    return p;
}

void SkellSnapAudioProcessor::setBool(const juce::String& id, bool v)
{
    if (auto* p = apvts.getParameter(id)) { p->beginChangeGesture(); p->setValueNotifyingHost(v ? 1.0f : 0.0f); p->endChangeGesture(); }
}

void SkellSnapAudioProcessor::toggleNote(int pc)
{
    if (pc < 0 || pc > 11) return;
    const uint16_t eff = effectiveMask();
    if (int(pScale->load() + 0.5f) != 5) {              // leaving a preset: copy it into the custom notes
        for (int i = 0; i < 12; ++i) setBool("n" + juce::String(i), (eff >> i) & 1);
        if (auto* s = apvts.getParameter("scale")) { s->beginChangeGesture(); s->setValueNotifyingHost(s->convertTo0to1(5.0f)); s->endChangeGesture(); }
    }
    const uint16_t next = uint16_t(eff ^ (1u << pc));
    if (next == 0) return;                               // always keep one target note
    setBool("n" + juce::String(pc), (next >> pc) & 1);
}

bool SkellSnapAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    const auto& o = l.getMainOutputChannelSet();
    return (o == juce::AudioChannelSet::mono() || o == juce::AudioChannelSet::stereo()) && o == l.getMainInputChannelSet();
}

void SkellSnapAudioProcessor::prepareToPlay(double sr, int)
{
    engine_.prepare(sr, juce::jmax(1, getTotalNumInputChannels()));
    engine_.setParams(readParams());
    engine_.reset();                                     // start exactly on the new home delay
    reported_ = engine_.latencySamples();
    setLatencySamples(reported_);
}

void SkellSnapAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int n = buffer.getNumSamples();
    for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c) buffer.clear(c, 0, n);

    engine_.setParams(readParams());
    const int lat = engine_.latencySamples();
    if (lat != reported_) { reported_ = lat; pending_.store(lat); triggerAsyncUpdate(); }

    engine_.process(buffer.getArrayOfWritePointers(), juce::jmin(2, buffer.getNumChannels()), n);
}

juce::AudioProcessorEditor* SkellSnapAudioProcessor::createEditor() { return new SkellSnapEditor(*this); }

void SkellSnapAudioProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, dest);
}
void SkellSnapAudioProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(apvts.state.getType())) apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SkellSnapAudioProcessor(); }
