#include "PluginEditor.h"
using namespace SnapTheme;

static const char* kNames[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };

void NoteRow::paint(juce::Graphics& g)
{
    const auto mask = proc.effectiveMask();
    const auto t = proc.telemetry();
    const int target = t.targetNote >= 0 ? t.targetNote % 12 : -1;
    const float w = getWidth() / 12.0f;
    for (int i = 0; i < 12; ++i) {
        auto r = juce::Rectangle<float>(i * w + 2.0f, 2.0f, w - 4.0f, getHeight() - 4.0f);
        const bool on = (mask >> i) & 1;
        g.setColour(on ? greenDim : raised); g.fillRoundedRectangle(r, 5.0f);
        g.setColour(on ? green : border);    g.drawRoundedRectangle(r, 5.0f, 1.0f);
        if (i == target && t.voiced) { g.setColour(cyan); g.drawRoundedRectangle(r.reduced(2.0f), 4.0f, 2.0f); }
        g.setColour(on ? bone : faint); g.setFont(juce::FontOptions(14.0f, juce::Font::bold));
        g.drawText(kNames[i], r, juce::Justification::centred);
    }
}
void NoteRow::mouseDown(const juce::MouseEvent& e)
{
    proc.toggleNote(juce::jlimit(0, 11, int(e.position.x / (getWidth() / 12.0f))));
    repaint();
}

void PitchMeter::paint(juce::Graphics& g)
{
    const auto t = proc.telemetry();
    auto b = getLocalBounds().toFloat();
    g.setColour(panel); g.fillRoundedRectangle(b, 8.0f);
    g.setColour(border); g.drawRoundedRectangle(b.reduced(0.5f), 8.0f, 1.0f);
    const auto bar = b.reduced(18.0f, 0.0f).withTrimmedTop(b.getHeight() * 0.55f).withHeight(14.0f);
    g.setColour(raised); g.fillRoundedRectangle(bar, 4.0f);
    g.setColour(faint);  g.fillRect(bar.getCentreX() - 1.0f, bar.getY() - 3.0f, 2.0f, bar.getHeight() + 6.0f);
    juce::String line = "---";
    if (t.voiced && t.targetNote >= 0) {
        const float c = juce::jlimit(-50.0f, 50.0f, t.cents);
        const float x = bar.getCentreX() + c / 50.0f * (bar.getWidth() * 0.5f);
        g.setColour(std::abs(t.cents) < 5.0f ? green : (std::abs(t.cents) < 25.0f ? cyan : violet));
        g.fillRoundedRectangle(x - 3.0f, bar.getY() - 4.0f, 6.0f, bar.getHeight() + 8.0f, 2.0f);
        line = juce::String(kNames[t.targetNote % 12]) + juce::String(t.targetNote / 12 - 1) + "   "
             + juce::String(t.inHz, 1) + " Hz  ->  " + juce::String(t.targetHz, 1) + " Hz   "
             + (t.cents >= 0 ? "+" : "") + juce::String(t.cents, 0) + " c";
    }
    g.setColour(bone); g.setFont(juce::FontOptions(20.0f, juce::Font::bold));
    g.drawText(line, b.withHeight(b.getHeight() * 0.5f).reduced(12.0f, 0.0f), juce::Justification::centred);
}

void SkellSnapEditor::setupKnob(Knob& k, const juce::String& id, const juce::String& text)
{
    k.s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    k.s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 78, 20);
    k.l.setText(text, juce::dontSendNotification);
    k.l.setJustificationType(juce::Justification::centred);
    k.l.setColour(juce::Label::textColourId, bone);
    addAndMakeVisible(k.s); addAndMakeVisible(k.l);
    k.a = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc.apvts, id, k.s);
}

SkellSnapEditor::SkellSnapEditor(SkellSnapAudioProcessor& p)
    : AudioProcessorEditor(&p), proc(p), notes(p), meter(p)
{
    laf.setColour(juce::Slider::rotarySliderFillColourId, green);
    laf.setColour(juce::Slider::rotarySliderOutlineColourId, raised);
    laf.setColour(juce::Slider::thumbColourId, bone);
    laf.setColour(juce::Slider::textBoxTextColourId, bone);
    laf.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    laf.setColour(juce::ComboBox::backgroundColourId, raised);
    laf.setColour(juce::ComboBox::textColourId, bone);
    laf.setColour(juce::ComboBox::outlineColourId, border);
    laf.setColour(juce::ComboBox::arrowColourId, green);
    laf.setColour(juce::PopupMenu::backgroundColourId, panel);
    laf.setColour(juce::PopupMenu::textColourId, bone);
    setLookAndFeel(&laf);

    key.addItemList({ "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 1);
    scale.addItemList({ "Chromatic", "Major", "Minor", "Major Pentatonic", "Minor Pentatonic", "Custom" }, 1);
    latency.addItemList({ "1 ms (Ultra)", "2.5 ms (Low)", "5 ms (Bass / Baritone)", "10 ms (Stable)" }, 1);
    for (auto* c : { &key, &scale, &latency }) addAndMakeVisible(*c);
    aKey = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(proc.apvts, "key", key);
    aScale = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(proc.apvts, "scale", scale);
    aLat = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(proc.apvts, "latency", latency);
    keyL.setText("KEY", juce::dontSendNotification);
    scaleL.setText("SCALE", juce::dontSendNotification);
    latL.setText("LATENCY", juce::dontSendNotification);
    for (auto* l : { &keyL, &scaleL, &latL, &infoL }) { l->setColour(juce::Label::textColourId, faint); addAndMakeVisible(*l); }
    infoL.setJustificationType(juce::Justification::centredRight);

    setupKnob(kRetune, "retune", "RETUNE"); setupKnob(kAmount, "amount", "AMOUNT");
    setupKnob(kHuman, "humanize", "HUMANIZE"); setupKnob(kRef, "ref", "A4 REF"); setupKnob(kMin, "minhz", "LOWEST PITCH");
    addAndMakeVisible(notes); addAndMakeVisible(meter);
    setSize(720, 470);
    startTimerHz(30);
}
SkellSnapEditor::~SkellSnapEditor() { setLookAndFeel(nullptr); }

void SkellSnapEditor::timerCallback()
{
    infoL.setText("reports " + juce::String(proc.latencyReported()) + " samples", juce::dontSendNotification);
    notes.repaint(); meter.repaint();
}
void SkellSnapEditor::paint(juce::Graphics& g)
{
    g.fillAll(black);
    g.setColour(panel); g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(8.0f), 12.0f);
    g.setColour(bone); g.setFont(juce::FontOptions(26.0f, juce::Font::bold));
    g.drawText("SKELL-SNAP", 24, 14, 300, 34, juce::Justification::centredLeft);
    g.setColour(faint); g.setFont(juce::FontOptions(13.0f));
    g.drawText("low-latency pitch correction", 24, 44, 300, 18, juce::Justification::centredLeft);
}
void SkellSnapEditor::resized()
{
    auto r = getLocalBounds().reduced(24);
    r.removeFromTop(56);
    auto top = r.removeFromTop(52);
    const int w = top.getWidth() / 3;
    auto a = top.removeFromLeft(w - 8); keyL.setBounds(a.removeFromTop(16)); key.setBounds(a.reduced(0, 2));
    top.removeFromLeft(8);
    auto b = top.removeFromLeft(w - 8); scaleL.setBounds(b.removeFromTop(16)); scale.setBounds(b.reduced(0, 2));
    top.removeFromLeft(8);
    latL.setBounds(top.removeFromTop(16)); latency.setBounds(top.reduced(0, 2));
    r.removeFromTop(10);
    notes.setBounds(r.removeFromTop(42));
    r.removeFromTop(10);
    meter.setBounds(r.removeFromTop(86));
    r.removeFromTop(8);
    auto row = r.removeFromTop(r.getHeight() - 22);
    const int kw = row.getWidth() / 5;
    for (auto* k : { &kRetune, &kAmount, &kHuman, &kRef, &kMin }) {
        auto c = row.removeFromLeft(kw);
        k->l.setBounds(c.removeFromTop(16)); k->s.setBounds(c);
    }
    infoL.setBounds(r);
}
