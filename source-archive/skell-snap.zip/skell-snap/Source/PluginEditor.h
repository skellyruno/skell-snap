#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

namespace SnapTheme {
const juce::Colour black(0xff07090a), panel(0xff14181a), raised(0xff1c2123), green(0xff39ff3a),
                   greenDim(0xff135c1a), bone(0xffe8e6da), violet(0xff9b5cff), cyan(0xff3affd9),
                   faint(0xff687176), border(0xff424d4f);
}

// 12 clickable pitch classes: lit = permitted target, ring = current target note
class NoteRow : public juce::Component {
public:
    explicit NoteRow(SkellSnapAudioProcessor& p) : proc(p) {}
    void paint(juce::Graphics& g) override;
    void mouseDown(const juce::MouseEvent& e) override;
private:
    SkellSnapAudioProcessor& proc;
};

// detected note, cents needle and target readout
class PitchMeter : public juce::Component {
public:
    explicit PitchMeter(SkellSnapAudioProcessor& p) : proc(p) {}
    void paint(juce::Graphics& g) override;
private:
    SkellSnapAudioProcessor& proc;
};

class SkellSnapEditor : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit SkellSnapEditor(SkellSnapAudioProcessor&);
    ~SkellSnapEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    SkellSnapAudioProcessor& proc;
    juce::LookAndFeel_V4 laf;
    NoteRow notes;
    PitchMeter meter;
    juce::ComboBox key, scale, latency;
    juce::Label keyL, scaleL, latL, infoL;
    struct Knob { juce::Slider s; juce::Label l; std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> a; };
    Knob kRetune, kAmount, kHuman, kRef, kMin;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> aKey, aScale, aLat;
    void setupKnob(Knob&, const juce::String& id, const juce::String& text);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SkellSnapEditor)
};
